package com.timawu.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager

class OverlayService : Service() {
    companion object {
        const val ACTION_STOP = "com.timawu.app.STOP"
        const val ACTION_PAUSE = "com.timawu.app.PAUSE"
    }

    private var view: MotionView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val wm get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_PAUSE -> { goForeground(); pause() }
            else -> { goForeground(); show() }
        }
        return START_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("timawu", "TIMAWU", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "timawu")
            .setContentTitle("TIMAWU aktif")
            .setContentText("Ketuk untuk berhenti")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(stop)
            .build()
        startForeground(1, n)
    }

    private fun show() {
        val p = getSharedPreferences("timawu", MODE_PRIVATE)
        if (view == null) {
            val v = MotionView(this)
            v.transparentBg = true
            v.alpha = 0.6f
            val lp = WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            wm.addView(v, lp)
            view = v
        }
        view?.mode = Mode.values()[p.getInt("mode", 0).coerceIn(0, Mode.values().size - 1)]
        view?.color = p.getInt("color", Cfg.DEFAULT_COLOR)
        p.edit().putBoolean("running", true).apply()
    }

    private fun pause() {
        val v = view
        if (v == null) { stopSelf(); return }
        v.visibility = View.INVISIBLE
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ view?.visibility = View.VISIBLE }, 60_000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
        getSharedPreferences("timawu", MODE_PRIVATE).edit().putBoolean("running", false).apply()
        super.onDestroy()
    }
}
