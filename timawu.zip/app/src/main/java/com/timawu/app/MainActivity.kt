package com.timawu.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var motion: MotionView
    private lateinit var themeBtn: TextView
    private lateinit var colorBtn: TextView
    private lateinit var startBtn: TextView
    private lateinit var status: TextView
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> runOnUiThread { refreshUi() } }

    private val colors = intArrayOf(
        0xFF7FD6A0.toInt(), 0xFF4CAF50.toInt(), 0xFF9CCC65.toInt(), 0xFF26A69A.toInt(),
        0xFF2E7D32.toInt(), 0xFFB7E4C7.toInt(), 0xFFA5D6A7.toInt(), 0xFF66BB6A.toInt(),
        0xFF80CBC4.toInt(), 0xFFCFD8DC.toInt(), 0xFFFFFFFF.toInt(), 0xFF8D9E94.toInt()
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun View.pressAnim(onClick: () -> Unit) {
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setInterpolator(OvershootInterpolator(3f)).setDuration(260).start()
            }
            false
        }
        setOnClickListener { onClick() }
    }

    private fun pill(text: String, filled: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = if (filled) 18f else 15f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(if (filled) Cfg.BG else Cfg.TEXT)
        setPadding(dp(18), dp(if (filled) 16 else 10), dp(18), dp(if (filled) 16 else 10))
        background = GradientDrawable().apply {
            cornerRadius = dp(100).toFloat()
            if (filled) setColor(Cfg.ACCENT) else {
                setColor(withA(Cfg.CARD, 200))
                setStroke(dp(1), withA(Cfg.ACCENT, 140))
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("timawu", MODE_PRIVATE)
        window.statusBarColor = Cfg.BG
        window.navigationBarColor = Cfg.BG

        val root = FrameLayout(this)
        motion = MotionView(this)
        root.addView(motion, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(56), dp(24), dp(32))
        }

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "TIMAWU"; textSize = 38f; typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f; setTextColor(Cfg.TEXT)
        }
        val sub = TextView(this).apply {
            text = "Selamat tinggal mabuk perjalanan"; textSize = 17f
            setTextColor(withA(Cfg.TEXT, 210)); setPadding(0, dp(6), 0, 0)
        }
        titleBox.addView(title); titleBox.addView(sub)
        val menuBtn = TextView(this).apply {
            text = "⋮"; textSize = 28f; setTextColor(Cfg.TEXT); setPadding(dp(14), 0, dp(4), dp(8))
        }
        menuBtn.pressAnim { showMenu(menuBtn) }
        top.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(menuBtn)
        col.addView(top)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(24), 0, 0)
        }
        themeBtn = pill("")
        colorBtn = pill("")
        themeBtn.pressAnim { showThemeMenu() }
        colorBtn.pressAnim { showColorDialog() }
        row.addView(themeBtn)
        row.addView(colorBtn, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(10) })
        col.addView(row)

        col.addView(View(this), LinearLayout.LayoutParams(0, 0, 1f))

        status = TextView(this).apply {
            textSize = 14f; gravity = Gravity.CENTER
            setTextColor(withA(Cfg.TEXT, 190)); setPadding(0, 0, 0, dp(14))
        }
        startBtn = pill("MULAI", true)
        startBtn.pressAnim { toggle() }
        col.addView(status, LinearLayout.LayoutParams(-1, -2))
        col.addView(startBtn, LinearLayout.LayoutParams(-1, -2))

        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        refreshUi()

        val items = listOf(title, sub, row, status, startBtn)
        items.forEachIndexed { i, v ->
            v.alpha = 0f; v.translationY = dp(24).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(100L + i * 90L).setDuration(450).start()
        }
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(listener)
        refreshUi()
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
        super.onPause()
    }

    private fun curMode() = Mode.values()[prefs.getInt("mode", 0).coerceIn(0, Mode.values().size - 1)]
    private fun curColor() = prefs.getInt("color", Cfg.DEFAULT_COLOR)
    private fun running() = prefs.getBoolean("running", false)

    private fun refreshUi() {
        motion.mode = curMode()
        motion.color = curColor()
        themeBtn.text = "Tema: ${curMode().label} ▾"
        val s = SpannableString("● Warna")
        s.setSpan(ForegroundColorSpan(curColor()), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        colorBtn.text = s
        startBtn.text = if (running()) "BERHENTI" else "MULAI"
        status.text = if (running()) "Aktif: titik tampil di atas aplikasi lain"
        else "Tekan Mulai, lalu buka aplikasi apa saja"
    }

    private fun applyChange() {
        refreshUi()
        if (running()) startForegroundService(Intent(this, OverlayService::class.java))
    }

    private fun showThemeMenu() {
        val pm = PopupMenu(this, themeBtn)
        Mode.values().forEach { pm.menu.add(it.label) }
        pm.setOnMenuItemClickListener { mi ->
            val m = Mode.values().first { it.label == mi.title.toString() }
            prefs.edit().putInt("mode", m.ordinal).apply()
            applyChange(); true
        }
        pm.show()
    }

    private fun showColorDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(8))
        }
        lateinit var dlg: AlertDialog
        colors.toList().chunked(4).forEach { chunk ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEach { c ->
                val sw = View(this).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(c)
                        if (c == curColor()) setStroke(dp(3), Color.WHITE)
                    }
                }
                sw.pressAnim {
                    prefs.edit().putInt("color", c).apply()
                    applyChange(); dlg.dismiss()
                }
                r.addView(sw, LinearLayout.LayoutParams(dp(52), dp(52)).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) })
            }
            box.addView(r)
        }
        dlg = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Pilih warna").setView(box).setNegativeButton("Batal", null).create()
        dlg.show()
    }

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add("Cara kerja")
        pm.menu.add("Jeda 1 menit")
        pm.setOnMenuItemClickListener { mi ->
            if (mi.title == "Cara kerja") {
                AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle("Cara kerja")
                    .setMessage("Saat mobil bergerak, tubuhmu merasakan gerakan tapi matamu melihat layar yang diam. Perbedaan ini membuat mual.\n\nTIMAWU menampilkan titik-titik yang bergerak mengikuti gerakan kendaraan (lewat sensor HP), sehingga mata dan tubuh \"sepakat\". Tekan Mulai, lalu pakai HP seperti biasa.")
                    .setPositiveButton("Mengerti", null).show()
            } else if (running()) {
                startForegroundService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_PAUSE))
                Toast.makeText(this, "Dijeda 1 menit", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "TIMAWU belum aktif", Toast.LENGTH_SHORT).show()
            }
            true
        }
        pm.show()
    }

    private fun toggle() {
        if (running()) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan \"Tampil di atas aplikasi lain\", lalu tekan Mulai lagi", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        startForegroundService(Intent(this, OverlayService::class.java))
    }
}
