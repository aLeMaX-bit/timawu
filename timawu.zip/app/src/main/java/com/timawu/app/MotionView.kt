package com.timawu.app

import android.content.Context
import android.graphics.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.View
import kotlin.math.*

object Cfg {
    val BG = 0xFF0E1712.toInt()
    val CARD = 0xFF1A2A21.toInt()
    val TEXT = 0xFFE8F3EC.toInt()
    val ACCENT = 0xFF7FD6A0.toInt()
    val DEFAULT_COLOR = 0xFF7FD6A0.toInt()
}

enum class Mode(val label: String) {
    TITIK("Titik-titik"), FOKUS("Fokus"), CAKRAWALA("Cakrawala"), SATU_WARNA("Satu warna")
}

fun withA(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

class MotionView(ctx: Context) : View(ctx), SensorEventListener {
    var mode: Mode = Mode.TITIK
        set(v) { field = v; invalidate() }
    var color: Int = Cfg.DEFAULT_COLOR
        set(v) { field = v; invalidate() }
    var transparentBg = false

    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val linear = sensor?.type == Sensor.TYPE_LINEAR_ACCELERATION
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    private var ax = 0f; private var az = 0f
    private var gx = 0f; private var gz = 0f
    private var ox = 0f; private var oy = 0f
    private var vx = 0f; private var vy = 0f
    private var last = 0L
    private var t = 0f
    private var registered = false

    private fun register() {
        if (!registered && sensor != null) {
            sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
            registered = true
        }
    }

    private fun unregister() {
        if (registered) { sm.unregisterListener(this); registered = false }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); register() }
    override fun onDetachedFromWindow() { unregister(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        if (v == VISIBLE) { register(); last = 0L; invalidate() } else unregister()
    }

    override fun onSensorChanged(e: SensorEvent) {
        var x = e.values[0]
        var z = e.values[2]
        if (!linear) {
            gx = gx * 0.92f + x * 0.08f
            gz = gz * 0.92f + z * 0.08f
            x -= gx; z -= gz
        }
        ax = ax * 0.85f + x * 0.15f
        az = az * 0.85f + z * 0.15f
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min(0.05f, (now - last) / 1e9f)
        last = now
        t += dt

        val k = 14f * d
        val lim = 70f * d
        val tx = (-ax * k).coerceIn(-lim, lim)
        val ty = (-az * k).coerceIn(-lim, lim)
        vx += ((tx - ox) * 60f - vx * 9f) * dt
        vy += ((ty - oy) * 60f - vy * 9f) * dt
        ox += vx * dt
        oy += vy * dt

        if (!transparentBg) c.drawColor(Cfg.BG)
        when (mode) {
            Mode.TITIK -> dots(c, false)
            Mode.FOKUS -> dots(c, true)
            Mode.CAKRAWALA -> horizon(c)
            Mode.SATU_WARNA -> wash(c)
        }
        postInvalidateOnAnimation()
    }

    private fun dots(c: Canvas, focus: Boolean) {
        val s = 58f * d
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2
        val maxD = hypot(cx, cy)
        paint.style = Paint.Style.FILL
        paint.shader = null
        val baseRow = -floor(oy / s).toInt() - 1
        val baseCol = -floor(ox / s).toInt() - 1
        var y = (((oy % s) + s) % s) - s
        var row = baseRow
        while (y < h + s) {
            val shift = if ((row and 1) == 0) 0f else s / 2
            var x = (((ox % s) + s) % s) - s + shift
            var col = baseCol
            while (x < w + s) {
                var a = 170
                if (focus) {
                    val f = ((hypot(x - cx, y - cy) / maxD - 0.35f) / 0.4f).coerceIn(0f, 1f)
                    a = (f * 200).toInt()
                }
                if (a > 6) {
                    val r = d * (3f + 1.2f * sin(t * 1.5f + row * 0.7f + col * 1.3f))
                    paint.color = withA(color, a)
                    c.drawCircle(x, y, r, paint)
                }
                x += s; col++
            }
            y += s; row++
        }
    }

    private fun horizon(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.save()
        c.rotate(ox / (70f * d) * 10f, w / 2, h / 2)
        c.translate(0f, oy * 0.6f)
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, h / 2, 0f, h * 1.2f, withA(color, 110), withA(color, 0), Shader.TileMode.CLAMP)
        c.drawRect(-w, h / 2, w * 2, h * 2, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f * d
        paint.color = withA(color, 200)
        c.drawLine(-w, h / 2, w * 2, h / 2, paint)
        paint.style = Paint.Style.FILL
        c.restore()
    }

    private fun wash(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            w / 2 + ox * 1.5f, h / 2 + oy * 1.5f, hypot(w, h) * 0.6f,
            intArrayOf(withA(color, 0), withA(color, 150)),
            floatArrayOf(0.4f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }
}
